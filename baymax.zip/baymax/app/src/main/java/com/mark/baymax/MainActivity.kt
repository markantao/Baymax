package com.mark.baymax

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val sick = findViewById<Button>(R.id.sicknesses)
        sick.setOnClickListener {
            val intent = Intent(this, sickness::class.java)
            startActivity(intent)
        }

        val injurys = findViewById<Button>(R.id.injurys)
        injurys.setOnClickListener {
            val intent = Intent(this, injury::class.java)
            startActivity(intent)
        }

    }
}
